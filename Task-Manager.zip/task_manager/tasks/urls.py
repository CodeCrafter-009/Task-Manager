from django.urls import path
from . import views

urlpatterns = [
    path('', views.task_list, name='task_list'),  # URL pattern for task list
    path('add/', views.add_task, name='add_task'),  # URL pattern for adding a new task
    path('edit/<int:id>/', views.edit_task, name='edit_task'),  # URL pattern for editing a task
    path('delete/<int:id>/', views.delete_task, name='delete_task'),  # URL pattern for deleting a task
    path('complete/<int:id>/', views.complete_task, name='complete_task'),  # URL pattern for completing a task
]
